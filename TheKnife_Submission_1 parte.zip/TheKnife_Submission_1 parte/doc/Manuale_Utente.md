# Manuale Utente — TheKnife

## Installazione
- Richiede JDK 17+
- Esegui: `java -jar bin/TheKnife.jar`

## Uso
- Avvio: scegli login/registrazione o modalità guest.
- Ricerca: filtra per città (obbligatorio), cucina, prezzo, delivery, prenotazione, stelle.
- Cliente: aggiungi/rimuovi preferiti; inserisci/modifica/elimina recensioni.
- Ristoratore: aggiungi ristorante; visualizza media e recensioni; rispondi alle recensioni.
- Logout: opzione "0) Logout" nei menu autenticati.
